package main.gasStation;

import java.time.LocalDate;
import java.time.Period;
import java.util.Random;

import static main.gasStation.Vehicle.Type.*;

public class Vignette {
    public enum Type {
        day(1, Period.ofDays(1)), month(10, Period.ofMonths(1)), year(60, Period.ofYears(1));

        private int priceMultiplier;
        private Period period;

        private Type(int priceMultiplier, Period period) {
            this.priceMultiplier = priceMultiplier;
            this.period = period;
        }

        public int getPriceMultiplier() {
            return priceMultiplier;
        }
    }

    public enum Color {
        red(car, 5, 5), green(truck, 7, 10), blue(bus, 9, 20);

        private Vehicle.Type vehicle;
        private double price;
        private int timeToStick; //sec

        Color(Vehicle.Type vehicle, double price, int timeToStick) {
            this.vehicle = vehicle;
            this.price = price;
            this.timeToStick = timeToStick;
        }

        public Vehicle.Type getVehicle() {
            return vehicle;
        }

        public double getPrice() {
            return price;
        }
    }
    //characteristics
    private final Color color;
    private final Type type;
    private LocalDate dateIssued;
    private final double price;
    private final Period period;

    public Vignette() {
        type = Type.values()[new Random().nextInt(Type.values().length)];
        color = Color.values()[new Random().nextInt(Color.values().length)];
        price = color.getPrice() * type.priceMultiplier;
        period = type.period;
    }

    public boolean hasExpired(LocalDate date){
        if(dateIssued == null){
            return false;
        }
        return dateIssued.plus(period).isBefore(date);
    }

    public double getPrice() {
        return price;
    }

    public void getPurchased(){
        dateIssued = LocalDate.now();
    }

    public Color getColor() {
        return color;
    }

    public Type getType() {
        return type;
    }

    @Override
    public String toString() {
        return String.format(color + " %.2f lv", price);
    }
}
